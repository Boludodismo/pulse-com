CREATE TABLE IF NOT EXISTS `procedure_kits` (
  `id` int AUTO_INCREMENT NOT NULL,
  `studioId` int NOT NULL DEFAULT 1,
  `name` varchar(255) NOT NULL,
  `description` text,
  `category` varchar(100) NOT NULL DEFAULT 'Geral',
  `isActive` tinyint NOT NULL DEFAULT 1,
  `createdAt` bigint NOT NULL DEFAULT 0,
  `updatedAt` bigint NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `procedure_kit_items` (
  `id` int AUTO_INCREMENT NOT NULL,
  `kitId` int NOT NULL,
  `materialId` int NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit` varchar(50) NOT NULL DEFAULT 'un',
  PRIMARY KEY (`id`)
);