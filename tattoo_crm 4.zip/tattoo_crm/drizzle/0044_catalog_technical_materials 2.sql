CREATE TABLE `catalog_brands` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `origin` varchar(100),
  `website` varchar(500),
  `isActive` tinyint NOT NULL DEFAULT 1,
  `createdAt` bigint NOT NULL DEFAULT 0,
  `updatedAt` bigint NOT NULL DEFAULT 0,
  CONSTRAINT `catalog_brands_id` PRIMARY KEY(`id`),
  CONSTRAINT `catalog_brands_slug_unique` UNIQUE(`slug`),
  KEY `catalog_brands_name_idx` (`name`)
);

CREATE TABLE `catalog_product_lines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `brandId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text,
  `isActive` tinyint NOT NULL DEFAULT 1,
  `createdAt` bigint NOT NULL DEFAULT 0,
  `updatedAt` bigint NOT NULL DEFAULT 0,
  CONSTRAINT `catalog_product_lines_id` PRIMARY KEY(`id`),
  CONSTRAINT `catalog_product_lines_brand_name_unique` UNIQUE(`brandId`,`name`),
  KEY `catalog_product_lines_category_idx` (`category`)
);

CREATE TABLE `catalog_variants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lineId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `sku` varchar(255),
  `category` varchar(100) NOT NULL,
  `format` varchar(100),
  `needleCount` int,
  `needleDiameter` decimal(5,2),
  `taper` varchar(100),
  `packageQuantity` int,
  `packageUnit` varchar(50),
  `application` text,
  `evidenceStatus` enum('fabricante','fornecedor','pendente','bloqueado') NOT NULL DEFAULT 'pendente',
  `sourceUrl` varchar(1000),
  `notes` text,
  `sortOrder` int NOT NULL DEFAULT 0,
  `isActive` tinyint NOT NULL DEFAULT 1,
  `createdAt` bigint NOT NULL DEFAULT 0,
  `updatedAt` bigint NOT NULL DEFAULT 0,
  CONSTRAINT `catalog_variants_id` PRIMARY KEY(`id`),
  KEY `catalog_variants_line_idx` (`lineId`),
  KEY `catalog_variants_category_idx` (`category`),
  KEY `catalog_variants_sku_idx` (`sku`),
  KEY `catalog_variants_format_idx` (`format`)
);

CREATE TABLE `supplier_catalog_offerings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supplierId` int NOT NULL,
  `brandId` int NOT NULL,
  `lineId` int,
  `variantId` int,
  `sourceUrl` varchar(1000),
  `evidenceStatus` enum('item','marca','pendente') NOT NULL DEFAULT 'pendente',
  `lastVerifiedAt` bigint,
  `notes` text,
  `isActive` tinyint NOT NULL DEFAULT 1,
  `createdAt` bigint NOT NULL DEFAULT 0,
  `updatedAt` bigint NOT NULL DEFAULT 0,
  CONSTRAINT `supplier_catalog_offerings_id` PRIMARY KEY(`id`),
  KEY `supplier_catalog_offerings_supplier_idx` (`supplierId`),
  KEY `supplier_catalog_offerings_brand_idx` (`brandId`),
  KEY `supplier_catalog_offerings_line_idx` (`lineId`),
  KEY `supplier_catalog_offerings_variant_idx` (`variantId`)
);

ALTER TABLE `materials` ADD COLUMN `catalogVariantId` int;
