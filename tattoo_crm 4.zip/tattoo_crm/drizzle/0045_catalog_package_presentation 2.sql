ALTER TABLE `catalog_variants` MODIFY COLUMN `packageUnit` varchar(500);
