import fs from 'node:fs/promises';
import mysql from 'mysql2/promise';

const catalogFile = '/home/ubuntu/materials-catalog-normalized.csv';

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') {
        field += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        field += char;
      }
      continue;
    }
    if (char === '"') {
      quoted = true;
    } else if (char === ',') {
      row.push(field);
      field = '';
    } else if (char === '\n') {
      row.push(field.replace(/\r$/, ''));
      rows.push(row);
      row = [];
      field = '';
    } else {
      field += char;
    }
  }
  if (field || row.length) {
    row.push(field.replace(/\r$/, ''));
    rows.push(row);
  }
  const [header, ...records] = rows;
  return records.filter((record) => record.some(Boolean)).map((record) => Object.fromEntries(header.map((key, i) => [key, record[i] ?? ''])));
}

function slug(value) {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function categoryFor(sourceBlock) {
  const value = sourceBlock.toLowerCase();
  if (value.includes('cartucho') || value.includes('agulha')) return 'Cartuchos e agulhas';
  if (value.includes('tinta') || value.includes('pigment')) return 'Tintas e pigmentos';
  if (value.includes('batoque') || value.includes('copo')) return 'Batoques e acessórios';
  if (value.includes('máquina') || value.includes('grip') || value.includes('bateria') || value.includes('fonte')) return 'Máquinas e alimentação';
  if (value.includes('stencil') || value.includes('transfer')) return 'Stencil e transferência';
  if (value.includes('higien') || value.includes('esteril') || value.includes('limpeza')) return 'Higienização e processamento';
  if (value.includes('pós') || value.includes('aftercare') || value.includes('curativo')) return 'Pós-tatuagem';
  if (value.includes('barreira') || value.includes('descart')) return 'Barreiras e descartáveis';
  return 'Outros insumos';
}

function lineFor(productLineModel) {
  const separator = productLineModel.indexOf(' — ');
  if (separator > 0) return productLineModel.slice(0, separator).trim();
  const dashSeparator = productLineModel.indexOf(' - ');
  if (dashSeparator > 0) return productLineModel.slice(0, dashSeparator).trim();
  return productLineModel.trim();
}

function firstNumber(value, decimals = false) {
  const normalized = String(value ?? '').replace(',', '.');
  const match = normalized.match(decimals ? /\d+(?:\.\d+)?/ : /\b\d+\b/);
  return match ? Number(match[0]) : null;
}

function evidenceStatus(dataStatus) {
  const status = String(dataStatus ?? '').toLowerCase();
  if (status.includes('pendente') || status.includes('validar')) return 'pendente';
  if (status.includes('fornecedor')) return 'fornecedor';
  return 'pendente';
}

function fitText(value, maxLength) {
  const text = String(value ?? '').trim();
  if (!text) return null;
  return text.length > maxLength ? text.slice(0, maxLength) : text;
}

const now = Date.now();
const text = await fs.readFile(catalogFile, 'utf8');
const records = parseCsv(text);
const connection = await mysql.createConnection(process.env.DATABASE_URL);

try {
  const [[existing]] = await connection.query('SELECT COUNT(*) AS total FROM catalog_variants');
  if (Number(existing.total) > 0 && process.env.CATALOG_RESEED !== '1') {
    console.log(`CATALOGO_JA_POPULADO=${existing.total}`);
    process.exit(0);
  }

  if (process.env.CATALOG_RESEED === '1') {
    await connection.query('DELETE FROM supplier_catalog_offerings');
    await connection.query('DELETE FROM catalog_variants');
    await connection.query('DELETE FROM catalog_product_lines');
    await connection.query('DELETE FROM catalog_brands');
  }

  const brandIds = new Map();
  const lineIds = new Map();
  let imported = 0;

  for (let index = 0; index < records.length; index += 1) {
    const record = records[index];
    const brandName = record.brand.trim();
    const variantName = record.product_line_model.trim();
    if (!brandName || !variantName) continue;

    const brandKey = slug(brandName);
    if (!brandIds.has(brandKey)) {
      await connection.execute(
        `INSERT INTO catalog_brands (name, slug, isActive, createdAt, updatedAt)
         VALUES (?, ?, 1, ?, ?)
         ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id), updatedAt = VALUES(updatedAt)`,
        [brandName, brandKey, now, now],
      );
      const [[brand]] = await connection.query('SELECT id FROM catalog_brands WHERE slug = ? LIMIT 1', [brandKey]);
      brandIds.set(brandKey, Number(brand.id));
    }

    const category = categoryFor(record.source_block);
    const lineName = lineFor(variantName);
    const lineKey = `${brandKey}:${category}:${lineName.toLowerCase()}`;
    if (!lineIds.has(lineKey)) {
      await connection.execute(
        `INSERT INTO catalog_product_lines (brandId, name, category, description, isActive, createdAt, updatedAt)
         VALUES (?, ?, ?, ?, 1, ?, ?)
         ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id), updatedAt = VALUES(updatedAt)`,
        [brandIds.get(brandKey), lineName, category, `Origem: ${record.source_block}`, now, now],
      );
      const [[line]] = await connection.query(
        'SELECT id FROM catalog_product_lines WHERE brandId = ? AND name = ? LIMIT 1',
        [brandIds.get(brandKey), lineName],
      );
      lineIds.set(lineKey, Number(line.id));
    }

    const needleDiameter = firstNumber(record.needle_diameter_mm, true);
    const needleCount = firstNumber(record.needle_count, false);
    const packageQuantity = firstNumber(record.presentation, false);
    const specificationNote = [
      record.configuration_raw ? `Configuração publicada: ${record.configuration_raw}` : '',
      record.needle_diameter_raw ? `Diâmetro publicado: ${record.needle_diameter_raw}` : '',
      record.needle_count_raw ? `Pontas publicadas: ${record.needle_count_raw}` : '',
	  record.taper ? `Taper publicado: ${record.taper}` : '',
	  record.presentation ? `Apresentação publicada: ${record.presentation}` : '',
      record.brazil_market_evidence ? `Mercado Brasil: ${record.brazil_market_evidence}` : '',
      record.source_reference ? `Fonte: ${record.source_reference}` : '',
      record.data_status ? `Status da curadoria: ${record.data_status}` : '',
    ].filter(Boolean).join('\n');

    await connection.execute(
      `INSERT INTO catalog_variants (
        lineId, name, sku, category, format, needleCount, needleDiameter, taper,
        packageQuantity, packageUnit, application, evidenceStatus, notes, sortOrder,
        isActive, createdAt, updatedAt
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`,
      [
        lineIds.get(lineKey),
        fitText(variantName, 255),
        record.source_sku_reference && !record.source_sku_reference.toLowerCase().includes('não publicado') ? fitText(record.source_sku_reference, 255) : null,
        category,
        fitText(record.configuration_family, 100),
        needleCount,
        needleDiameter,
        record.taper && !record.taper.toLowerCase().includes('não aplicável') ? fitText(record.taper, 100) : null,
        packageQuantity,
        fitText(record.presentation, 500),
        record.application || null,
        evidenceStatus(record.data_status),
        specificationNote || null,
        index + 1,
        now,
        now,
      ],
    );
    imported += 1;
  }

  const [[summary]] = await connection.query(
    `SELECT
      (SELECT COUNT(*) FROM catalog_brands) AS brands,
      (SELECT COUNT(*) FROM catalog_product_lines) AS product_lines,
      (SELECT COUNT(*) FROM catalog_variants) AS variants`,
  );
  console.log(`CATALOGO_IMPORTADO=${imported}`);
  console.log(`MARCAS=${summary.brands};LINHAS=${summary.product_lines};VARIACOES=${summary.variants}`);
} finally {
  await connection.end();
}
