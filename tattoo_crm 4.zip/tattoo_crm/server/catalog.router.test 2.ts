import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const dbMocks = vi.hoisted(() => ({
  listCatalogBrands: vi.fn(),
  listCatalogProductLines: vi.fn(),
  searchCatalogVariants: vi.fn(),
  listSupplierCatalogOfferings: vi.fn(),
  createSupplierCatalogOffering: vi.fn(),
  deactivateSupplierCatalogOffering: vi.fn(),
  getCatalogVariantById: vi.fn(),
  createMaterial: vi.fn(),
}));

vi.mock("./db", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./db")>();
  return { ...actual, ...dbMocks };
});

import { appRouter } from "./routers";

function createContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "catalog-admin",
      name: "Administrador",
      email: "admin@example.com",
      loginMethod: "local",
      role: "admin",
      studioId: 1,
      artistId: null,
      isActive: 1,
      passwordHash: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastSignedIn: new Date().toISOString(),
    },
    req: { headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("catalog router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("encaminha busca por marca, formato e diâmetro sem perder filtros técnicos", async () => {
    dbMocks.searchCatalogVariants.mockResolvedValue([]);
    const caller = appRouter.createCaller(createContext());

    await caller.catalog.search({
      query: "Kwadron 7RL",
      brandId: 3,
      formats: ["RL"],
      needleDiameter: 0.35,
      limit: 40,
    });

    expect(dbMocks.searchCatalogVariants).toHaveBeenCalledWith({
      query: "Kwadron 7RL",
      brandId: 3,
      formats: ["RL"],
      needleDiameter: 0.35,
      limit: 40,
    });
  });

  it("cria vínculo de fornecedor sem persistir URL vazia como evidência", async () => {
    dbMocks.createSupplierCatalogOffering.mockResolvedValue(9);
    const caller = appRouter.createCaller(createContext());

    const result = await caller.catalog.createSupplierOffering({
      supplierId: 1,
      brandId: 2,
      evidenceStatus: "marca",
      sourceUrl: "",
    });

    expect(result).toEqual({ id: 9 });
    expect(dbMocks.createSupplierCatalogOffering).toHaveBeenCalledWith({
      supplierId: 1,
      brandId: 2,
      evidenceStatus: "marca",
      sourceUrl: undefined,
    });
  });

  it("adiciona uma variação além da primeira página de busca ao estoque preservando dados operacionais", async () => {
    dbMocks.getCatalogVariantById.mockResolvedValue({
      id: 319,
      brandName: "WJX",
      lineName: "Acme",
      name: "Round Liner",
      sku: "1207RLT",
      category: "Cartuchos e agulhas",
    });
    dbMocks.createMaterial.mockResolvedValue(55);
    const caller = appRouter.createCaller(createContext());

    const result = await caller.catalog.addToStock({
      variantId: 319,
      supplierId: 1,
      unit: "cx",
      currentStock: 2,
      minStock: 1,
      avgPrice: 89.9,
      notes: "Lote será conferido no recebimento",
    });

    expect(result).toEqual({ id: 55 });
    expect(dbMocks.createMaterial).toHaveBeenCalledWith({
      name: "WJX · Acme · Round Liner · 1207RLT",
      category: "Cartuchos e agulhas",
      unit: "cx",
      currentStock: "2",
      minStock: "1",
      avgPrice: "89.9",
      supplierId: 1,
      catalogVariantId: 319,
      notes: "Lote será conferido no recebimento",
    });
  });
});
