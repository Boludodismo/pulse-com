import { describe, expect, it } from "vitest";
import {
  calculateKitEstimatedCost,
  normalizeProcedureKitItems,
  procedureKitFormSchema,
  procedureKitItemsSchema,
} from "./procedureKitValidation";

describe("procedure kit validation", () => {
  it("accepts a kit with one valid material", () => {
    const result = procedureKitFormSchema.safeParse({
      name: "Kit Preto e Cinza",
      category: "Tatuagem",
      items: [{ materialId: 10, quantity: 2, unit: "un" }],
    });
    expect(result.success).toBe(true);
  });

  it("defaults the category when omitted", () => {
    const result = procedureKitFormSchema.parse({
      name: "Kit Básico",
      items: [{ materialId: 10, quantity: 1, unit: "un" }],
    });
    expect(result.category).toBe("Geral");
  });

  it("rejects an empty kit", () => {
    const result = procedureKitItemsSchema.safeParse([]);
    expect(result.success).toBe(false);
  });

  it("rejects zero or negative quantities", () => {
    expect(procedureKitItemsSchema.safeParse([{ materialId: 10, quantity: 0, unit: "un" }]).success).toBe(false);
    expect(procedureKitItemsSchema.safeParse([{ materialId: 10, quantity: -1, unit: "un" }]).success).toBe(false);
  });

  it("rejects an invalid material id", () => {
    const result = procedureKitItemsSchema.safeParse([{ materialId: 0, quantity: 1, unit: "un" }]);
    expect(result.success).toBe(false);
  });

  it("normalizes quantities to database-safe strings", () => {
    const result = normalizeProcedureKitItems([
      { materialId: 10, quantity: 2.5, unit: " ml " },
      { materialId: 11, quantity: 1, unit: "un" },
    ]);
    expect(result).toEqual([
      { materialId: 10, quantity: "2.5", unit: "ml" },
      { materialId: 11, quantity: "1", unit: "un" },
    ]);
  });

  it("calculates the estimated kit cost", () => {
    expect(calculateKitEstimatedCost([
      { quantity: 2, avgPrice: 3.5 },
      { quantity: 1, avgPrice: 10 },
    ])).toBe(17);
  });

  it("returns zero for an empty cost list", () => {
    expect(calculateKitEstimatedCost([])).toBe(0);
  });

  it("accepts decimal quantities", () => {
    const result = procedureKitItemsSchema.safeParse([{ materialId: 10, quantity: 0.25, unit: "ml" }]);
    expect(result.success).toBe(true);
  });

  it("rejects more than fifty items", () => {
    const items = Array.from({ length: 51 }, (_, index) => ({ materialId: index + 1, quantity: 1, unit: "un" }));
    expect(procedureKitItemsSchema.safeParse(items).success).toBe(false);
  });
});
